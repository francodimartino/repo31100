def funcion_modulo2():
    print("Hola, soy una funcion del modulo2")

def nueva_funcion():
    print("Hola, soy una funcion nueva")