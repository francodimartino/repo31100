def funcion_paquete():
    print("Hola, soy una funcion del paquete")